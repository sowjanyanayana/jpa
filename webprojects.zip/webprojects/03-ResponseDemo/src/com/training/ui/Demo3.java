package com.training.ui;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Demo3
 */
@WebServlet("/Demo3")
public class Demo3 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		List<String> playerNames=new ArrayList<>();
		response.setContentType("text/html");
		
		playerNames.add("sowji");
		playerNames.add("rani");
		playerNames.add("rohini");
		playerNames.add("mounika");
		playerNames.add("veena");
		int i=0;
		for (String string : playerNames) {
			out.println("<ul>");
			out.println("<li>"+playerNames.get(i)+"</li>");
			i++;
			out.println("</ul>");
		}
		int j=0;
		out.println("<ol>");
		for (String string : playerNames) {
			
			out.println("<li>"+playerNames.get(j)+"</li>");
			j++;			
		}
		out.println("</ol>");
		
	}

}
