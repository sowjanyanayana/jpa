package com.training.ui;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.training.entity.Player;

/**
 * Servlet implementation class Demo5
 */
@WebServlet("/Demo5")
public class Demo5 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		Set<Player> player = new HashSet<>();

		Player p1 = new Player(101, "sowjanya", 5, 500, 200, true);
		player.add(p1);
		Player p2 = new Player(102, "sindhu", 3, 800, 300, false);
		player.add(p2);
		Player p3 = new Player(103, "rani", 6, 300, 206, true);
		player.add(p3);
		Player p4 = new Player(104, "rohini", 10, 200, 33, false);
		player.add(p4);
		Player p5 = new Player(105, "veena", 1, 700, 263, true);
		player.add(p5);
		Player p6 = new Player(106, "sruthi", 8, 650, 195, false);
		player.add(p6);
		Player p7 = new Player(107, "divya", 9, 475, 296, true);
		player.add(p7);
		Player p8 = new Player(108, "mounika", 10, 200, 162, true);
		player.add(p8);
		Player p9 = new Player(109, "siri", 5, 750, 29, false);
		player.add(p9);
		Player p10 = new Player(110, "silpa", 11, 350, 438, true);
		player.add(p10);
		Player p11 = new Player(111, "avi", 13, 950, 82, true);
		player.add(p11);

		response.setContentType("text/html");
		out.println("<head>");
		out.println("<link href='Style.css' rel='stylesheet'>");
		out.println("<head>");

		out.println("<body>");
		out.println("<table>");
		out.println("<tr>");
		out.println("<th>PLAYER ID  " + "</th>");
		out.println("<th>PLAYER NAME  " + "</th>");
		out.println("<th>NO OF MATCHES  " + "</th>");
		out.println("<th>RUNS SCORED  " + "</th>");
		out.println("<th>NO OF WICKETS  " + "</th>");
		out.println("<th>CAPTAIN  " + "</th>");
		out.println("<th>BATTING RATING  " + "</th>");
		out.println("<th>BOWLING RATING  ");
		out.println("</tr>");
		int i = 0;

		for (Player player2 : player) {
			out.println("<tr>");
			out.println("<td>" + player2.getPlayerId() + "</td>");
			out.println("<td>" + player2.getPlayerName() + "</td>");
			out.println("<td>" + player2.getNoOfMathches() + "</td>");
			out.println("<td>" + player2.getTotalRunsScored() + "</td>");
			out.println("<td>" + player2.getNoOfWickets() + "</td>");
			out.println("<td>" + player2.isCaptain() + "</td>");
			out.println("<td>" + player2.getBattingRating() + "</td>");
			out.println("<td>" + player2.getBowlingRating() + "</td>");
			out.println("</tr>");
		}

		out.println("<table>");
		out.println("</body>");
	}

}
