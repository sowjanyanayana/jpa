package com.training.entity;

public class Doctor {

	String name="sowjanya";
	double consultingFee=1000;
	int experience =10;
	Clinic clinic=new Clinic();
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getConsultingFee() {
		return consultingFee;
	}
	public void setConsultingFee(double consultingFee) {
		this.consultingFee = consultingFee;
	}
	public int getExperience() {
		return experience;
	}
	public void setExperience(int experience) {
		this.experience = experience;
	}
	public Clinic getClinic() {
		return clinic;
	}
	public void setClinic(Clinic clinic) {
		this.clinic = clinic;
	}
	
	
}
