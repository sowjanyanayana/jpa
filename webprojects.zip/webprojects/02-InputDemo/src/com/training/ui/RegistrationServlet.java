package com.training.ui;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.training.entity.Customer;

/**
 * Servlet implementation class RegistrationServlet
 */
@WebServlet("/reg")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		PrintWriter out = response.getWriter();
		Customer customer = new Customer();
		String strId = request.getParameter("txtId");
		if (strId != null) {
			int id = Integer.parseInt(strId);
			customer.setId(id);
		}

		String strName = request.getParameter("txtName");
		if (strName != null) {

			customer.setName(strName);
		}
		
		String strGender = request.getParameter("radGender");
		if (strName != null) {
			int gender=Integer.parseInt(strGender);		
			customer.setGender(gender);
		}
		
		String strIsPrivilage = request.getParameter("checkprevilaged");
		if (strIsPrivilage == null) {
			customer.setPrivilage(false);
		}
		else if(strIsPrivilage.equals("yes")){
			customer.setPrivilage(true);
		}
		
		
		String strEmail = request.getParameter("txtEmail");
		if (strEmail != null && strEmail.matches("[a-z0-9]{5,}[@][a-z]{3,}[.][a-z]{2,}")) {
			customer.setEmail(strEmail);
		}
		
		String strPhone = request.getParameter("txtphone");
		if (strPhone != null && strPhone.length()==10 ) {

			customer.setPhone(strPhone);
		}
		
		String strAddress = request.getParameter("txtaddress");
		if (strAddress != null) {

			customer.setAddress(strAddress);
		}
		
		String strDOJ = request.getParameter("txtdoj");
		if (strDOJ != null) {
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		Date doj;
		try {
			doj = sdf.parse(strDOJ);
			customer.setDateOfJoining(doj);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		String strDes = request.getParameter("txtdesc");
		if (strDes != null) {

			customer.setDescription(strDes);
		}
		String strBal = request.getParameter("txtbal");
		if (strBal != null) {
			Double balanceAmount=Double.parseDouble(strBal);
			customer.setBalanceAmount(balanceAmount);
		}
		
		String strRate = request.getParameter("txtrate");
		if (strRate != null) {
			int rating=Integer.parseInt(strRate);
			customer.setCustomerRating(rating);
		}
		
		
		}
		out.println(customer.getId());
		out.println(customer.getName());
		out.println(customer.getEmail());
		out.println(customer.getPhone());
		out.println(customer.getAddress());
		out.println(customer.getDescription());
		out.println(customer.getCustomerRating());
		
	}

}
