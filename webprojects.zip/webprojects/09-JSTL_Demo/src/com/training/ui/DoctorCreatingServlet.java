package com.training.ui;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.training.entity.Doctor;

/**
 * Servlet implementation class DoctorCreatingServlet
 */
@WebServlet("/DoctorCreatingServlet")
public class DoctorCreatingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		List<Doctor> doctors=new ArrayList<Doctor>();
		
		Doctor  doctor1=new Doctor();
		doctor1.setId(1);
		doctor1.setName("sowjanya");
		doctor1.setGender("F");
		doctor1.setQualification("MBBS");
		doctor1.setFee(1000.00);
		doctor1.setExperience(10);
		request.setAttribute("DOC", doctor1);
		doctors.add(doctor1);
		
		Doctor  doctor2=new Doctor();
		doctor2.setId(2);
		doctor2.setName("sindhu");
		doctor2.setGender("F");
		doctor2.setQualification("nurse");
		doctor2.setFee(2000.00);
		doctor2.setExperience(5);
		request.setAttribute("DOC", doctor2);
		doctors.add(doctor2);
		
		Doctor  doctor3=new Doctor();
		doctor3.setId(1);
		doctor3.setName("rani");
		doctor3.setGender("F");
		doctor3.setQualification("dermatologist");
		doctor3.setFee(10000.00);
		doctor3.setExperience(20);
		request.setAttribute("DOC", doctor3);
		doctors.add(doctor3);
		
		Doctor  doctor4=new Doctor();
		doctor4.setId(1);
		doctor4.setName("avinash");
		doctor4.setGender("M");
		doctor4.setQualification("RMP");
		doctor4.setFee(2000.00);
		doctor4.setExperience(1);
		request.setAttribute("DOC", doctor4);
		doctors.add(doctor4);
		
		Doctor  doctor5=new Doctor();
		doctor5.setId(1);
		doctor5.setName("bhargav");
		doctor5.setGender("M");
		doctor5.setQualification("dentist");
		doctor5.setFee(30000.00);
		doctor5.setExperience(12);
		request.setAttribute("DOC", doctor5);
		doctors.add(doctor5);
		
		request.setAttribute("DOCTORS", doctors);
		RequestDispatcher dispatcher=request.getRequestDispatcher("Display4.jsp");
		dispatcher.forward(request, response);

	
	}

}
