package com.capg.paymentwallet.service;

import com.capg.paymentwallet.bean.AccountBean;
import com.capg.paymentwallet.dao.AccountDAOImpl;
import com.capg.paymentwallet.dao.IAccountDao;
import com.capg.paymentwallet.exception.CustomerException;
import com.capg.paymentwallet.exception.CustomerExceptionMessage;

public class AccountServiceImpl implements IAccountService {
	static IAccountDao dao = new AccountDAOImpl();

	@Override
	public boolean createAccount(AccountBean accountBean) throws Exception {

		validate(accountBean);

		return dao.createAccount(accountBean);

	}

	@Override
	public double deposit(AccountBean accountBean, double depositAmount) throws Exception {
		validateAmount(depositAmount);

		return dao.deposit(accountBean, depositAmount);

	}

	@Override
	public double withdraw(AccountBean accountBean, double withdrawAmount) throws Exception {
		validateAmount(withdrawAmount);

		return dao.withdraw(accountBean, withdrawAmount);

	}

	@Override
	public double fundTransfer(AccountBean transferingAccountBean, AccountBean beneficiaryAccountBean,
			double transferAmount) throws Exception {
		validateAmount(transferAmount);

		return dao.fundsTransfer(transferingAccountBean, beneficiaryAccountBean, transferAmount);
	}

	@Override
	public AccountBean findAccount(int accountId) throws Exception {
		IAccountDao dao = new AccountDAOImpl();
		return dao.findAccount(accountId);

	}

	public boolean validate(AccountBean accountBean) throws Exception {
		if (accountBean.getCustomerBean().getFirstName()== null) {
			throw new CustomerException(CustomerExceptionMessage.ERROR8);
		}
		else if (!(accountBean.getCustomerBean().getFirstName().matches("[A-Za-z]{3,15}"))) {
			throw new CustomerException(CustomerExceptionMessage.ERROR1);
		}
		if (accountBean.getCustomerBean().getLastName()== null) {
			throw new CustomerException(CustomerExceptionMessage.ERROR8);
		}
		else if (!(accountBean.getCustomerBean().getLastName().matches("[A-Za-z]{3,15}"))) {
			throw new CustomerException(CustomerExceptionMessage.ERROR2);
		}
		if (accountBean.getCustomerBean().getEmailId()== null) {
			throw new CustomerException(CustomerExceptionMessage.ERROR8);
		}
		else if (!(accountBean.getCustomerBean().getEmailId()
				.matches("[a-zA-Z0-9]{6,15}[@][a-zA-Z]{4,10}[.][cC][Oo][Mm]"))) {
			throw new CustomerException(CustomerExceptionMessage.ERROR3);
		}
		char phn = accountBean.getCustomerBean().getPhoneNo().toString().charAt(0);
		if (!(phn == '6' || phn == '7' || phn == '8' || phn == '9')) {
			throw new CustomerException("phone number must start with 6 or 7 or 8 or 9");
		}
		if (!(accountBean.getCustomerBean().getPhoneNo().toString().matches("[6-9][0-9]{9}"))) {
			throw new CustomerException(CustomerExceptionMessage.ERROR4);
		}
		if (!(accountBean.getCustomerBean().getPanNum().toString().matches("[A-Z]{4}[0-9]{5}[A-Z]"))) {
			throw new CustomerException(CustomerExceptionMessage.ERROR5);
		}
		if (accountBean.getCustomerBean().getAddress()== null) {
			throw new CustomerException(CustomerExceptionMessage.ERROR8);
		}
		else if (!(accountBean.getCustomerBean().getAddress().matches("[A-Za-z0-9 ]{6,30}"))) {
			throw new CustomerException(CustomerExceptionMessage.ERROR6);
		}
		return true;
	}

	@Override
	public void validateAmount(double amount) throws Exception {
		if (amount <= 0) {
			throw new CustomerException(CustomerExceptionMessage.ERROR7);
		}

	}

}
