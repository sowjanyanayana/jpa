package com.capg.bankapp.exception;

public class Exception1 extends Exception{

	public Exception1() {
		super();
	}

	public Exception1(String arg0) {
		super(arg0);
	}
	
	

}
