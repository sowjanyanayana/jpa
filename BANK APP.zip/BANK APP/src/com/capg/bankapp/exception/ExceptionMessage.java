package com.capg.bankapp.exception;

public class ExceptionMessage extends Exception1{

	public static final String ERROR1 = "firstname should be atleast 4 characters";
	public static final String ERROR2 = "name should not be null";
	public static final String ERROR12 = "last name should be atleast 4 characters";

	public static final String ERROR3 = "age between 18 and 100";
	
	public static final String ERROR4 = "adhar should be 12 digits";
	public static final String ERROR5 = "adhar should not be null";
	
	public static final String ERROR6 = "phno should be 10 digits";
	public static final String ERROR7 = "phno should not be null";
	
	public static final String ERROR8 = "not added";
	public static final String ERROR9 = "enter correct details";
	public static final String ERROR11 = "enter valid phone number";
	public static final String ERROR13 = "enter valid characters in last name";
	public static final String ERROR14 = "balance should be greater than zero";
	
}
