package com.cg.bankapp.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capg.bankapp.bean.CustomerBean;
import com.capg.bankapp.bean.TransactionBean;
import com.capg.bankapp.exception.ExceptionMessage;
import com.capg.bankapp.service.BankServiceImp;
import com.capg.bankapp.service.IBankService;

public class Test1 {

	static IBankService service=null;
	@BeforeClass
	public static void getBankDetails(){
		
		service=new BankServiceImp();
						
	}
	@Test
	public void validationForPositive() throws Exception{
		CustomerBean bean=new CustomerBean();
		bean.setFirstName("sowjanya");
		bean.setLastName("nayana");
		bean.setPhNo(9032974524L);
		bean.setAge(21);
		bean.setAdhar(254781121382L);
		bean.setBalance(100);
		boolean result=service.validations(bean);
		assertTrue(result);
				
	}
	
	@Test(expected=Exception.class)
	public void validationForFirstName() throws Exception{
		CustomerBean bean=new CustomerBean();
		bean.setFirstName("so");
		bean.setLastName("nayana");
		bean.setPhNo(9032974524L);
		bean.setAge(21);
		bean.setAdhar(254781121382L);
		bean.setBalance(100);
		service.validations(bean);
				
	}
	
	@Test(expected=Exception.class)
	public void validationForFirstNameNotNull() throws Exception{
		CustomerBean bean=new CustomerBean();
		bean.setFirstName(null);
		bean.setLastName("nayana");
		bean.setPhNo(9032974524L);
		bean.setAge(21);
		bean.setAdhar(254781121382L);
		bean.setBalance(0);
		service.validations(bean);
				
	}
	
	@Test(expected=Exception.class)
	public void validationForLastName() throws Exception{
		CustomerBean bean=new CustomerBean();
		bean.setFirstName("sowji");
		bean.setLastName("na12");
		bean.setPhNo(9032974524L);
		bean.setAge(21);
		bean.setAdhar(254781121382L);
		bean.setBalance(100);
		service.validations(bean);
				
	}
	
	@Test(expected=Exception.class)
	public void validationForLastNameNotNull() throws Exception{
		CustomerBean bean=new CustomerBean();
		bean.setFirstName("sowji");
		bean.setLastName(null);
		bean.setPhNo(9032974524L);
		bean.setAge(21);
		bean.setAdhar(254781121382L);
		bean.setBalance(0);
		service.validations(bean);
				
	}
	
	@Test(expected=Exception.class)
	public void validationForPhNoLength() throws Exception{
		CustomerBean bean=new CustomerBean();
		bean.setFirstName("so");
		bean.setLastName("nayana");
		bean.setPhNo(903297452L);
		bean.setAge(21);
		bean.setAdhar(254781121382L);
		bean.setBalance(100);
		service.validations(bean);
				
	}
	
	
	@Test(expected=Exception.class)
	public void validationForAge() throws Exception{
		CustomerBean bean=new CustomerBean();
		bean.setFirstName("so");
		bean.setLastName("nayana");
		bean.setPhNo(9032974524L);
		bean.setAge(2);
		bean.setAdhar(254781121382L);
		bean.setBalance(100);
		service.validations(bean);
			
	}
	
	@Test(expected=Exception.class)
	public void validationForAdhar() throws Exception{
		CustomerBean bean=new CustomerBean();
		bean.setFirstName("so");
		bean.setLastName("nayana");
		bean.setPhNo(9032974524L);
		bean.setAge(21);
		bean.setAdhar(25478112138L);
		bean.setBalance(100);
		service.validations(bean);
				
	}
	
	@Test(expected=Exception.class)
	public void validationForBalance() throws Exception{
		CustomerBean bean=new CustomerBean();
		bean.setFirstName("so");
		bean.setLastName("nayana");
		bean.setPhNo(9032974524L);
		bean.setAge(21);
		bean.setAdhar(254781121382L);
		bean.setBalance(0);
		service.validations(bean);
				
	}
	
	@Test(expected=Exception.class)
	public void validationForBalanceNegative() throws Exception{
		CustomerBean bean=new CustomerBean();
		bean.setFirstName("so");
		bean.setLastName("nayana");
		bean.setPhNo(9032974524L);
		bean.setAge(21);
		bean.setAdhar(254781121382L);
		bean.setBalance(-100);
		service.validations(bean);
				
	}
	
	@Test
	public void DepositPositive(){
		CustomerBean bean=new CustomerBean();
		assertTrue(service.deposit(bean, 1000, 9032974524L));
				
	}
	
	@Test
	public void DepositWrongNumber(){
		CustomerBean bean=new CustomerBean();
		assertFalse(service.deposit(bean, 1000,90329752L));
				
	}
	
	@Test
	public void DepositWrongBalance(){
		CustomerBean bean=new CustomerBean();
		assertFalse(service.deposit(bean, -1000, 9032974524L));
				
	}
	@Test
	public void withDrawPositive(){
		CustomerBean bean=new CustomerBean();
		assertTrue(service.withDraw(bean, 1000, 9032974524L));
	}
	
	@Test
	public void withDrawWrongNumber(){
		CustomerBean bean=new CustomerBean();
		assertFalse(service.withDraw(bean, 1000, 903294524L));
	}

	@Test
	public void withDrawWrongBalancer(){
		CustomerBean bean=new CustomerBean();
		assertFalse(service.withDraw(bean, 100000, 903294524L));
	}
	
	@Test
	public void fundTransferPositive(){
		CustomerBean bean=new CustomerBean();
		assertTrue(service.fundTransfer(bean, 9032974524L, 9032652514L, 1000));
	}
	
	@Test
	public void fundTransferSenderWrong(){
		CustomerBean bean=new CustomerBean();
		assertFalse(service.fundTransfer(bean, 903297454L, 9032652514L, 1000));
	}
	
	@Test
	public void fundTransferRecieverWrong(){
		CustomerBean bean=new CustomerBean();
		assertFalse(service.fundTransfer(bean, 9032974524L, 90326514L, 1000));
	}
	
	@Test
	public void fundTransferBalance(){
		CustomerBean bean=new CustomerBean();
		assertFalse(service.fundTransfer(bean, 9032974524L, 9032652514L, 100000));
	}
	
	@Test
	public void showBalancePositive(){
		CustomerBean bean=new CustomerBean();
		double result=service.showBalance(bean, 9032974524L);
		assertEquals(result, 4000, 100);
	}
	@Test
	public void showBalancePhoneNoWrong(){
		CustomerBean bean=new CustomerBean();
		double result=service.showBalance(bean, 903297452L);
		assertEquals(result, 0, 100);
	}
	
	
}
