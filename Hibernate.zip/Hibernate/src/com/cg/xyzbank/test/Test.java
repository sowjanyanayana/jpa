package com.cg.xyzbank.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;

import com.cg.xyzbank.bean.BankBean;
import com.cg.xyzbank.bean.CustomerBean;
import com.cg.xyzbank.service.BankServiceImpl;
import com.cg.xyzbank.service.IBankService;

public class Test {

	static IBankService service = null;

	@BeforeClass
	public static void createObject() {
		service = new BankServiceImpl();
	}

	@org.junit.Test(expected = Exception.class)
	public void createAccount() throws Exception {
		BankBean bankBean = new BankBean();
		bankBean.setBalance(2000);
		CustomerBean bean = new CustomerBean();
		bean.setFirstName("silpa");
		bean.setLastName("nayana");
		bean.setAge(21);
		bean.setAdhar(245781121382L);
		bean.setPhoneNo(9440640920L);
		service.validations(bean, bankBean);
	}

	@org.junit.Test(expected = Exception.class)
	public void createAccountForFirstName() throws Exception {
		BankBean bankBean = new BankBean();
		bankBean.setBalance(2000);
		CustomerBean bean = new CustomerBean();
		bean.setFirstName("sil");
		bean.setLastName("nayana");
		bean.setAge(21);
		bean.setAdhar(245781121382L);
		bean.setPhoneNo(9440640920L);
		service.validations(bean, bankBean);
	}

	@org.junit.Test(expected = Exception.class)
	public void createAccountForFirstNameForNull() throws Exception {
		BankBean bankBean = new BankBean();
		bankBean.setBalance(2000);
		CustomerBean bean = new CustomerBean();
		bean.setFirstName(null);
		bean.setLastName("nayana");
		bean.setAge(21);
		bean.setAdhar(245781121382L);
		bean.setPhoneNo(9440640920L);
		service.validations(bean, bankBean);
	}

	@org.junit.Test(expected = Exception.class)
	public void createAccountForFirstNameForCharacters() throws Exception {
		BankBean bankBean = new BankBean();
		bankBean.setBalance(2000);
		CustomerBean bean = new CustomerBean();
		bean.setFirstName("si1234");
		bean.setLastName("nayana");
		bean.setAge(21);
		bean.setAdhar(245781121382L);
		bean.setPhoneNo(9440640920L);
		service.validations(bean, bankBean);
	}

	@org.junit.Test(expected = Exception.class)
	public void createAccountForLastName() throws Exception {
		BankBean bankBean = new BankBean();
		bankBean.setBalance(2000);
		CustomerBean bean = new CustomerBean();
		bean.setFirstName("silpa");
		bean.setLastName("na");
		bean.setAge(21);
		bean.setAdhar(245781121382L);
		bean.setPhoneNo(9440640920L);
		service.validations(bean, bankBean);
	}

	@org.junit.Test(expected = Exception.class)
	public void createAccountForLastNameForNull() throws Exception {
		BankBean bankBean = new BankBean();
		bankBean.setBalance(2000);
		CustomerBean bean = new CustomerBean();
		bean.setFirstName("silpa");
		bean.setLastName(null);
		bean.setAge(21);
		bean.setAdhar(245781121382L);
		bean.setPhoneNo(9440640920L);
		service.validations(bean, bankBean);
	}

	@org.junit.Test(expected = Exception.class)
	public void createAccountForLastNameForCharacters() throws Exception {
		BankBean bankBean = new BankBean();
		bankBean.setBalance(2000);
		CustomerBean bean = new CustomerBean();
		bean.setFirstName("silpa");
		bean.setLastName("1234");
		bean.setAge(21);
		bean.setAdhar(245781121382L);
		bean.setPhoneNo(9440640920L);
		service.validations(bean, bankBean);
	}

	@org.junit.Test(expected = Exception.class)
	public void createAccountForAge() throws Exception {
		BankBean bankBean = new BankBean();
		bankBean.setBalance(2000);
		CustomerBean bean = new CustomerBean();
		bean.setFirstName("silpa");
		bean.setLastName("nayana");
		bean.setAge(2);
		bean.setAdhar(245781121382L);
		bean.setPhoneNo(9440640920L);
		service.validations(bean, bankBean);
	}

	@org.junit.Test(expected = Exception.class)
	public void createAccountForAdhar() throws Exception {
		BankBean bankBean = new BankBean();
		bankBean.setBalance(2000);
		CustomerBean bean = new CustomerBean();
		bean.setFirstName("silpa");
		bean.setLastName("nayana");
		bean.setAge(21);
		bean.setAdhar(24578112L);
		bean.setPhoneNo(9440640920L);
		service.validations(bean, bankBean);
	}

	@org.junit.Test(expected = Exception.class)
	public void createAccountForPhoneNumber() throws Exception {
		BankBean bankBean = new BankBean();
		bankBean.setBalance(2000);
		CustomerBean bean = new CustomerBean();
		bean.setFirstName("silpa");
		bean.setLastName("nayana");
		bean.setAge(21);
		bean.setAdhar(245781121382L);
		bean.setPhoneNo(9440640920L);
		service.validations(bean, bankBean);
	}

	@org.junit.Test(expected = Exception.class)
	public void createAccountForWrongPhoneNumber() throws Exception {
		BankBean bankBean = new BankBean();
		bankBean.setBalance(2000);
		CustomerBean bean = new CustomerBean();
		bean.setFirstName("silpa");
		bean.setLastName("nayana");
		bean.setAge(21);
		bean.setAdhar(245781121382L);
		bean.setPhoneNo(2598746325L);
		service.validations(bean, bankBean);
	}

	@org.junit.Test(expected = Exception.class)
	public void createAccountForPhoneNumberLength() throws Exception {
		BankBean bankBean = new BankBean();
		bankBean.setBalance(2000);
		CustomerBean bean = new CustomerBean();
		bean.setFirstName("silpa");
		bean.setLastName("nayana");
		bean.setAge(21);
		bean.setAdhar(245781121382L);
		bean.setPhoneNo(01120L);
		service.validations(bean, bankBean);
	}

	@org.junit.Test(expected = Exception.class)
	public void createAccountForIntialBalance() throws Exception {
		BankBean bankBean = new BankBean();
		bankBean.setBalance(-2000);
		CustomerBean bean = new CustomerBean();
		bean.setFirstName("silpa");
		bean.setLastName("nayana");
		bean.setAge(21);
		bean.setAdhar(245781121382L);
		bean.setPhoneNo(9440640920L);
		service.validations(bean, bankBean);
	}

	@org.junit.Test
	public void Deposit() {
		BankBean bankBean = new BankBean();
		bankBean.setBalance(5000);
		bankBean.setPhoneNo(9032974524L);
		assertTrue(service.deposit(bankBean, 2000));
	}
	@org.junit.Test
	public void DepositForWrongNumber() {
		BankBean bankBean = new BankBean();
		bankBean.setBalance(5000);
		assertFalse(service.deposit(bankBean, 2000));
	}
	@org.junit.Test
	public void withDraw(){
		BankBean bankBean = new BankBean();
		bankBean.setBalance(5000);
		bankBean.setPhoneNo(9032974524L);
		assertTrue(service.withDraw(bankBean, 1000));
	}
	@org.junit.Test
	public void withDrawForWrongNumber(){
		BankBean bankBean = new BankBean();
		bankBean.setBalance(5000);
		assertFalse(service.withDraw(bankBean, 1000));
	}
	
	@org.junit.Test
	public void withDrawForWrongBalance(){
		BankBean bankBean = new BankBean();
		bankBean.setBalance(5000);
		assertFalse(service.withDraw(bankBean, 100000));
	}
	
	@org.junit.Test
	public void FundTransfer(){
		BankBean bankBean1 = new BankBean();
		bankBean1.setBalance(5000);
		bankBean1.setPhoneNo(9032974524L);
		BankBean bankBean2 = new BankBean();
		bankBean1.setBalance(5000);
		bankBean2.setPhoneNo(8978974524L);
		assertTrue(service.fundTransfer(1000,bankBean1, bankBean2));
	}
	
	@org.junit.Test
	public void FundTransferForWrongSender(){
		BankBean bankBean1 = new BankBean();
		bankBean1.setBalance(5000);
		
		BankBean bankBean2 = new BankBean();
		bankBean1.setBalance(5000);
		bankBean1.setPhoneNo(9032974524L);
		assertFalse(service.fundTransfer(1000,bankBean1, bankBean2));
	}
	@org.junit.Test
	public void FundTransferForWrongReciever(){
		BankBean bankBean1 = new BankBean();
		bankBean1.setBalance(5000);
		bankBean1.setPhoneNo(9032974524L);
		BankBean bankBean2 = new BankBean();
		bankBean1.setBalance(5000);
		assertFalse(service.fundTransfer(1000,bankBean1, bankBean2));
	}
	@org.junit.Test
	public void FundTransferForWrongAmount(){
		BankBean bankBean1 = new BankBean();
		bankBean1.setBalance(5000);
		BankBean bankBean2 = new BankBean();
		bankBean1.setBalance(5000);
		assertFalse(service.fundTransfer(100000,bankBean1, bankBean2));
	}
	
	
	
}
