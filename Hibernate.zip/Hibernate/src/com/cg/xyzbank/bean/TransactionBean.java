package com.cg.xyzbank.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="t2")
public class TransactionBean {
	@Id	
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int tansid; 
	public int getTansid() {
		return tansid;
	}
	public void setTansid(int tansid) {
		this.tansid = tansid;
	}
	private Long phoneNo;
	private Double deposit;
	private Double withDraw;
	private Double fundTransfer;
	private String transactionType;
	
	
		public Long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(Long phoneNo) {
		this.phoneNo = phoneNo;
	}
	public Double getDeposit() {
		return deposit;
	}
	public void setDeposit(Double deposit) {
		this.deposit = deposit;
	}
	public Double getWithDraw() {
		return withDraw;
	}
	public void setWithDraw(Double withDraw) {
		this.withDraw = withDraw;
	}
	public Double getFundTransfer() {
		return fundTransfer;
	}
	public void setFundTransfer(Double fundTransfer) {
		this.fundTransfer = fundTransfer;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	
	@Override
	public String toString() {
		return "TransactionBean [deposit=" + deposit + ", withDraw=" + withDraw
				+ ", fundTransfer=" + fundTransfer + ", transactionType="
				+ transactionType +  "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((phoneNo == null) ? 0 : phoneNo.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TransactionBean other = (TransactionBean) obj;
		if (phoneNo == null) {
			if (other.phoneNo != null)
				return false;
		} else if (!phoneNo.equals(other.phoneNo))
			return false;
		return true;
	}
	
}
