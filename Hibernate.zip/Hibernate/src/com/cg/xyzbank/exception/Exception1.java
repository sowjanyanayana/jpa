package com.cg.xyzbank.exception;

public class Exception1 extends Exception {

	public Exception1() {
		super();
	}

	public Exception1(String message) {
		super(message);
	}

	
	
}
